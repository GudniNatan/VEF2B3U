var element = document.querySelector('li');
var finalElement = element.nextSibling.nextSibling;
console.log(finalElement);