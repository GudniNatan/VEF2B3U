var listi = ["Mjólk", "Brauð", "Kaffi", "Hundamatur", "Sellerí"];
for (var i = 0; i < listi.length; i++) {
	document.write("<p>" + listi[i] + "</p>");
}